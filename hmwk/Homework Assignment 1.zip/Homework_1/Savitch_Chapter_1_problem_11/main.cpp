/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on February 28, 2017, 11:32 AM
 * Purpose: Write program that outputs "CS !" in large block letters.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    
    cout<<"********************************************\n"
            "\n"
            "       CCC          SSSS      !!\n"
            "     C     C      S     S     !!\n"
            "    C            S            !!\n"
            "   C              S           !!\n"
            "   C                SSSS      !!\n"
            "   C                    S     !!\n"
            "    C                    S    !!\n"
            "     C     C      S     S     \n"
            "       CCC          SSSS      00"
            "\n"
            "********************************************\n"
            "   Computer Science is Cool Stuff!!!\n"<<endl;
    
    
    return 0;
}

