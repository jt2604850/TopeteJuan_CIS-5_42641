/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on March 10, 2017, 9:52 AM
 * Purpose: Write a program for the Babylonian algorithm using guesses.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist



//Function Prototypes



//Execution begins here
int main() 
{
    //Declare variables
    
    float guess,n,r;
    

    
    //Input data
    cout << "In this program try to guess the square root of n.\n";
    cout << "Take a guess: ";
    cin  >> guess;
    
   
    //Map inputs to outputs.
   
    guess= (guess + r)/2; // 
    r = n/guess; 
   
    //Output data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);  
    cout.precision(2);
    cout << "The square root of n is ";
    cout << guess; //The square root of n according to your guess.
    
   
    return 0;
}

