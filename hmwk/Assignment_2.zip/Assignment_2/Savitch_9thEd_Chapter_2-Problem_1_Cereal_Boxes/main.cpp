/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on March 9, 2017, 9:52 AM
 * Purpose:  Convert amount of cereal from tons to ounce.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist



//Function Prototypes



//Execution begins here
int main() 
{
    //Declare variables
    
    double ounces, Boxes; // amount of cereal
    int Metric_Ton;
    

    
    //Input data
    cout << "This program calculates number of cereal boxes to make a ton.\n";
    cout << "Enter in size of cereal in ounces:";
    cin  >> ounces;
   
    //Map inputs to outputs.
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);  
    cout.precision(2);
    ounces= 35,273.92; // Ounces to make a metric ton. 
    Boxes = Metric_Ton/ounces;
   
    //Output data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);  
    cout.precision(2);
    cout << "Number of boxes:"; cout << Boxes; //Total number of boxes.
    
   
    return 0;
}

