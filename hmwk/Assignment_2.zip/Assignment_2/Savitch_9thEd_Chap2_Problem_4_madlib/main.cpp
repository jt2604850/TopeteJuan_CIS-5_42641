/* 
  File:   main.cpp
  Author: Juan Topete
  Created on March 9, 2017, 9:35 PM
  Purpose:  Create a game of mad lib by asking a group of questions to the user.
 */

//System Libraries
#include <string>
#include <iostream>
using namespace std;



//Executable code begins here!!!
int main(int argc, char** argv)
{
    string Instructor_Name, Name, Food, Number_100120, Adjective,Color,Animal;

    
    cout << "Enter in the Following:"<<endl;
    cout << "The first or last name of your instructor"<<endl;
    cin  >> Instructor_Name;
    cout << "Your name"<<endl;
    cin  >> Name;
    cout << "A food"<<endl;
    cin  >> Food;
    cout << "A number between 100 and 120"<<endl;
    cin  >> Number_100120;
    cout << "An Adjective"<<endl;
    cin  >> Adjective;
    cout << "A color"<<endl;
    cin  >> Color;
    cout << "An animal"<<endl;
    cin  >> Animal;
    
   
    
    
    
    cout << "Dear Instructor "; cout << Instructor_Name<<endl;
    cout <<        "\n ";
    cout <<        "I am sorry that I am unable to turn in my homework at this time. First";
    cout <<        "I ate a rotten "; cout << Food; cout <<  " which made me turn "; cout << Color; cout << " and extremely ill. I";
    cout <<        " came down with a fever of "; cout << Number_100120; cout << ". Next my "; cout << Adjective; cout <<" pet ";
    cout << Animal ; cout<< " must have smelled the remains of the "; cout << Food; cout << " on my homework,";
    cout <<       "because he ate it. I am currently rewriting my homework and hope you ";
    cout <<        "will accept it late\n";
    cout <<        "\n";
    cout <<        "Sincerely,\n";
    cout << Name;
             
            
   

    return 0;
}