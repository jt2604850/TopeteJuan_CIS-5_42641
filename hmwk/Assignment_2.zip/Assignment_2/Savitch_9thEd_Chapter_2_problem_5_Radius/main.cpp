/* 
  File:   main.cpp
  Author: Juan Topete
  Created on March 6, 2017, 9:45 PM
  Purpose: Create a program that computes the volume of a sphere given the 
 radius. Put it in proper format.
 */

//System Libraries
#include <iostream>
using namespace std;



int main() 
{
    //Declare variables
    double radius,vm;
    
    //input data
    cout << "Enter radius of a sphere." <<endl;
    cin  >> radius;
            
    //Maps Input and Output Formula
    vm = (4.0/3.0)* 3.1415 * radius * radius * radius;
    
    //output data
    cout << "The volume is " << vm << endl;

    return 0;
}