/* 
  File:   main.cpp
  Author: Juan Topete
  Created on March 9, 2017, 10:32 PM
  Purpose: Write a program that calculates the total grade for N classroom
 * exercises. 
 */

//System Libraries
#include <iostream>
using namespace std;

const int total_pts = 10;

int main() 
{
    //Declare variables
    int score, n, nt;
    float averageall;
    
    //input data
    cout << "How many exercises to input? " <<endl;
    cin  >> n; 
    cout << "percent received for each exercise "; 
    cin >> score;
    
    
            
    //Maps Input and Output Formula
      
        averageall = score/n;
        nt = n * 10;   
        
    //output data 
    cout << "Total Points possible for excise: 10 \n"; 
    cout << "Your total is "; cout << averageall; cout<<"out of "; cout <<nt;

    return 0;
}