/* 
  File:   main.cpp
  Author: Juan Topete
  Created on March 9, 2017, 9:35 PM
  Purpose: Modify Program that reads in ten whole numbers and outputs the sum
  of all numbers greater than zero, less than zero,takes the average of positive
  numbers, average of negative numbers, the sum and average of all numbers.
 */

//System Libraries
#include <iostream>
using namespace std;



int main() 
{
    //Declare variables
    int number1, number2, number3, number4, number5, number6, number7,number8,
        number9, number10, Sumpos, Sumneg, Sumall, averagepos, averageneg, averageall;
    
    //input data
    cout << "Enter 10 whole numbers one each on every line." <<endl;
    cin  >>     number1; 
    cin  >>     number2;
    cin  >>     number3;
    cin  >>     number4;
    cin  >>     number5; 
    cin  >>     number6; 
    cin  >>     number7;
    cin  >>     number8;
    cin  >>     number9; 
    cin  >>     number10;
    
            
    //Maps Input and Output Formula
       
        Sumpos= number1 + number2 + number3 + number4 + number5 + number6 + 
                number7,number8 + number9 + number10 > 0;
        Sumneg= number1 + number2 + number3 + number4 + number5 +number6 + 
                number7 + number8 + number9 + number10 < 0;
        Sumall= number1 + number2 + number3 + number4 + number5 + number6 + 
                number7 + number8 + number9 + number10;
        averagepos= Sumpos/number1, number2, number3, number4, number5, number6, 
                number7, number8, number9, number10 > 0;
        averageneg= Sumpos/number1, number2, number3, number4, number5, number6, 
                number7, number8, number9, number10 < 0;
        averageall= Sumall/10;
                
    //output data
    cout << "The sum of all positives" <<endl;    
    cout << Sumpos <<endl;
    cout << "The sum of all negatives" <<endl;
    cout << Sumneg <<endl;
    cout << "The sum of all numbers" <<endl;
    cout << Sumall <<endl;
    cout << "The average of all positives" <<endl;    
    cout << averagepos <<endl;
    cout << "The average of all negatives" <<endl;
    cout << averageneg <<endl;
    cout << "The average of all numbers" <<endl;
    cout << averageall;

    return 0;
}