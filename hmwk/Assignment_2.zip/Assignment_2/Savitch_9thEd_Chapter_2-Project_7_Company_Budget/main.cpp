/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on March 10, 2017, 9:52 AM
 * Purpose: Write a program to gauge the expect cost of an item(pencils) over
 a span of 2 years.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist



//Function Prototypes




//Execution begins here
int main() 
{
    //Declare variables
    
    float pencils;
    int count= 0.02;

    
    //Input data
    cout << "In this program the value of pencils will increase in 2 years\n";
    cout << "Inflation= 2% \n";
  
    
   
    //Map inputs to outputs.
   
    while (pencils < 0.200)
    {
        pencils = 0.02 * count;
        count++;
    }
    //Output data
    cout << "After 2 years ";
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);  
    cout.precision(2);
    cout << "pencils will go up by $" << pencils << endl;
    
    
   
    return 0;
}

