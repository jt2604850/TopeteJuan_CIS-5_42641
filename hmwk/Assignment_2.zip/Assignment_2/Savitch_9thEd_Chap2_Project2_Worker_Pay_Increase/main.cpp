/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on March 9, 2017, 11:05 PM
 * Purpose:  Calculate the workers pay increase of 7.6% for 6 months.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants
const double Pay_Increase= .076; // Pay increase of 7.6%

//Function Prototypes


//Execution begins here
int main() {
   
    //Declare and initialize variables
  
  float monthsal, total_amount; // Monthly salary 
 
    //Input data
    cout<<"Enter monthly salary ";
    cin >> monthsal;
    
    
    
    //Map inputs to outputs or process the data
    total_amount= (monthsal * Pay_Increase) + monthsal *6;
            
    
    //Output the transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);  
    cout.precision(2);        
    cout<< "Total amount in 6 months =$"; cout<< total_amount << endl;
    
    
    return 0;
}

