/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on March 9th, 2017, 11:15 PM
 * Purpose:  Calculate the workers pay increase of 7.6% for any # of months.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants
const double Pay_Increase= .076; // Pay increase of 7.6%

//Function Prototypes


//Execution begins here
int main() {
   
    //Declare and initialize variables
  
  float monthsal, total_amount, Number; // Monthly salary. Number of months 
 
    //Input data
    cout<<"Enter monthly salary ";
    cin >> monthsal;
    cout <<"Enter in number of months";
    cin >> Number;
    
    
    //Map inputs to outputs or process the data
    total_amount= (monthsal * Pay_Increase) + monthsal *Number;
            
    
    //Output the transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);  
    cout.precision(2);        
    cout<< "Total amount =$"; cout<< total_amount << endl;
    
    

    return 0;
}

