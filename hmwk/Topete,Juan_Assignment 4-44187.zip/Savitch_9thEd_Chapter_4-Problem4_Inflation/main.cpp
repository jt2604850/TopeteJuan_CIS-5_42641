/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on March 30, 2017, 9:52 PM
 * Purpose: Write a program to gauge the rate of inflation for a particular item
 * for the past year.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist



//Function Prototypes




//Execution begins here
int main() 
{
    //Declare variables
    float price,oldprice; //The current price and the year ago price
    double  percent; //Rate of inflation
    
    
   //Input
    cout << "Enter in the current price"<<endl;
    cin >> price;
    cout << "Enter in the old price from one year ago"<<endl;
    cin >> oldprice;
    
   //Conversion map input to output
    percent= price/oldprice;
   //Output transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout << "Inflation rate is "<<percent<<"%"<<endl;
            
    return 0;
    }

