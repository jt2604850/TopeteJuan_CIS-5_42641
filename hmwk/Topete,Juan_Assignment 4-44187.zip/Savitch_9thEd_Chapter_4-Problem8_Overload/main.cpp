/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on April 2, 2017, 9:42 PM
 * Purpose: Write a program with overload functions including int,long, 
 * float and double. This program will take the average of three different
 * numbers.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist



//Function Prototypes
double total(double n1,double n2,double n3);// The total average



//Execution begins here
int main() 
{
    //Declare variables
    int n1; //The first number 
    float n2;// The second number
    long n3;// The third number
    
   //Input
    cout<< "This program will take the total average of three numbers\n";
    cout<< "Enter three numbers";
    cin>>n1>>n2>>n3;
    double total =(n1+n2+n3)/3;
    
   //Output transformed data
   cout<<"The total average is "<<total;

  return 0;
}
    
   
    
    
