/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on  April 1, 2017, 9:52 PM
 * Purpose: Compute the annual after-tax cost of a new house for one year.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist



//Function Prototypes




//Execution begins here
int main() 
{
    //Declare variables
    float price,mor; //The price of the house and annual mortgage
    double  down, loan, tax, cost; //Initial loan, tax saving and down payment
    
    
   //Input
    cout << "Enter in the price of the house"<<endl;
    cin >> price;
    cout << "Enter in the down payment"<<endl;
    cin >> down;
    
   //Conversion map input to output
    tax=.35*down;
    loan = price-down;  
    mor = .03*loan+.06*loan;
    cost = mor-tax;
   //Output transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout << "The total cost of ownership for the first year is $"<<cost<<endl;
            
    return 0;
    }

