/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on March 30, 2017, 9:52 PM
 * Purpose: Write a program to simulate a vending machine that sells deep fried 
 * twinkies at $3.50 a piece.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist



//Function Prototypes




//Execution begins here
int main() 
{
    //Declare variables
    float coin,twinkie;
    float dime,dollar,nickel,quarter;
    float total;
    
   //Input
    cout << "Deep fried twinkies $3.50"<<endl;
    cout << "Enter in a dollar, quarter, dime or nickel type one"<<endl;
    cin >> coin;
    
   //Conversion input to output
    //coin=dime,dollar,nickel,quarter;
    //dime=.1;
    //dollar=1.00;
    //nickel=.05;
    //quarter=.25;   

    
    twinkie=3.50;
       
     if (total <3.50)
         cout<<" "<<endl;
     else
     if (total = 3.50)
    
        cout<<"enjoy your deep fried twinkie";
     
     else
    if (total >3.50)
    
        cout<<"enjoy your deep fried twinkie take your change";
        
     


    
    while (coin=dime)
    {
        total=coin;
        cout<<"enter next coin or dollar";
        cin>>coin;
    }
    while (coin=1)
    {
        total=coin;
        cout<<"enter next coin or dollar";
        cin>>coin;
    }
    while (coin=.05)
    {
        total=coin;
        cout<<"enter next coin or dollar";
        cin>>coin;
    }
    while (coin=.25)
    {
        total=coin;
        cout<<"enter next coin or dollar";
        cin>>coin;
    }
    
    
   //Output transformed data
   
    
    return 0;
    
    
}