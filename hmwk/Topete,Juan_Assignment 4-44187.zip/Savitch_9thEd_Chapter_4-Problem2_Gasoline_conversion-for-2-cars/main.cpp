/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on March 30, 2017, 9:52 PM
 * Purpose: Write a program to read in liters the miles per gallon of gasoline
 * used for two cars. Then the program tells which car is more fuel efficient.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist



//Function Prototypes

double mpg (int liter, double miles ); //Used because there are two calculations.


//Execution begins here
int main() 
{
    //Declare variables
    int liter1, liter2; 
    float miles1 ,mpg1, miles2,mpg2 ;
    
    
   //Input
    cout << "Enter liters of gasoline for car 1"<<endl;
    cin >> liter1;
    cout << "enter miles driven for car 1 "<<endl;
    cin >> miles1;
    cout << "Enter liters of gasoline for car 2"<<endl;
    cin >> liter2;
    cout << "enter miles driven for car 2 "<<endl;
    cin >> miles2;
   //Conversion map input to output
     mpg1 =miles1/liter1*.264179;
     mpg2 =miles2/liter2*.264179;
   //Output transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout << mpg1 <<" (miles per gallon for car 1) " <<endl;
    cout << mpg2 <<" (miles per gallon for car 2) " <<endl;
    if (mpg1 > mpg2)
        cout<<"The first car is more fuel efficient";
    else
        cout<<"The second car is more fuel efficient";
    return 0;
    }

