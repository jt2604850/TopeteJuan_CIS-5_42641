/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on April 1, 2017, 7:02 PM
 * Purpose: Enhance the previous program to estimate prices over the course of
 * two years. 
 * .
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist



//Function Prototypes




//Execution begins here
int main() 
{
    //Declare variables
    float price,oldprice; //The current price and the year ago price
    double  percent,f1,f2; //Rate of inflation and estimated prices.
    
    
   //Input
    cout << "Enter in the current price"<<endl;
    cin >> price;
    cout << "Enter in the old price from one year ago"<<endl;
    cin >> oldprice;
    
   //Conversion map input to output
    percent= price/oldprice;
    f1= percent*oldprice-oldprice;
    f2= percent*price;
   //Output transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout << "Inflation rate is "<<percent<<"%"<<endl;
    cout << "The price the item gone up by $"<<f1<<endl;
    cout << "The estimated price for the item in one year $"<<f2<<endl;
    return 0;
    }

