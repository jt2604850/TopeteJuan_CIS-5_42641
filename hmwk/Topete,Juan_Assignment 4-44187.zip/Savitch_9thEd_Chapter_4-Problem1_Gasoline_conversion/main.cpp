/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on March 30, 2017, 9:52 PM
 * Purpose: Write a program to read in liters the miles per gallon of gasoline.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist



//Function Prototypes




//Execution begins here
int main() 
{
    //Declare variables
    float miles, gallons, liter,mpg;
    
    
    
   //Input
    cout << "Enter liters of gasoline"<<endl;
    cin >> liter;
    cout << "enter miles driven "<<endl;
    cin >> miles;
    
   //Conversion input to output
     gallons =.264179 * liter;
     mpg =miles/gallons;
   //Output transformed data
    cout << mpg <<" (miles per gallon) " ;
    
    return 0;
    }

