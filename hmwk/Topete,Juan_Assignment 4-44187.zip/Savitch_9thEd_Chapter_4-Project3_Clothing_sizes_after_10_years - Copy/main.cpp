/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on March 30, 2017, 9:01 PM
 * Purpose: Write a program that asks for users clothing sizes after 10 years.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist



//Function Prototypes




//Execution begins here
int main() 
{
    //Declare variables
    int height, weight,age; // information about user
    float hat, jacket,jackadj, waist,old,fat; //Hat, jacket, and waist sizes
    
    
   //Input
    cout << "Enter in your height in inches"<<endl;
    cin >> height;
    cout << "Your weight in pounds"<<endl;
    cin >> weight;
    cout << "What is your Age?"<<endl;
    cin >> age;
   //Conversion map input to output
    
    hat=weight/height*2.9;
    
    
    if (age>20) //Used to adjust jacket size for people over 30(after ten years)
        old=age-20*.125;
    else 
        old=0;
     if (age>18) //Used to adjust waist size for people over 28(after ten years)
        fat=age-18*.1;
    else 
        fat=0;   
    waist=weight/5.7+fat;
    jacket=height*weight;
    jackadj=jacket/288+old;
   //Output transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout << "Your hat size in 10 years will be "<<hat<<"inches"<<endl;
    cout << "Your jacket size in  10 years will be "<<jackadj<<"inches"<<endl;
    cout << "Your waist size in 10 years will be "<<waist<<"inches"<<endl;
            
    return 0;
    }

