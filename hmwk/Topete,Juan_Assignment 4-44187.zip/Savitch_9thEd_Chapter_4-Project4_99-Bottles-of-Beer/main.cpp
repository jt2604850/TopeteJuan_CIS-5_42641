/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on April 3, 2017, 1:23 PM
 * Purpose: Write a program that outputs the lyrics to ninety-nine bottles on
 * the wall.
 */

//System Libraries
#include <iostream>  //Input - Output Library

using namespace std; //Name-space under which system libraries exist



//Function Prototypes




//Execution begins here
int main() 
{
    //Declare variables
    int beer;
    
   //Input
  
    cout << "Lyrics to ninety-nine bottles of beer on the wall"<<endl;
    
   //Conversion input to output
    beer=99;
    while (beer>0)
    {
        cout<<beer<<" bottles of beer on the wall,\n";
        cout<<beer<<" bottles of beer\n";
        cout<<"take one down,pass it around\n";
        cout<<beer<<" bottles of beer on the wall"<<endl;
        beer=beer-1;
    }
   //Output transformed data
  
            cout<< "That's it";
    return 0;
    
    
}