/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on May 5, 2017, 2:10 PM
 * Purpose: Write a program that converts feet & inches into meters & centimeters.
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

int main()
{ 
 float feet,meter,centi,inch; 
 int input; 
 //Input
 cout << "Enter the length in feet and then the remaining inches: "; 
 cin >> feet; 
 cin >> inch;
 //Conversions
 meter = feet * 0.3048; 
 inch = feet * 12 ;
 centi =meter * 100;
 //Output data
 cout << feet << " in feet is " << meter << " in meters.\n"; 
 cout << centi << "  in centimeters\n";
 cout << "try again 'y' or 'n'\n";
 cin >> input;
 if (input='y')
 {   
 return 0;
 }
  
cout << "End of program.";
    return 0;
}

