/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on May 5, 2017, 3:29 PM
 * Purpose: Write a program that combines the previous two programs into one.
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

int main()
{ 
 float feet, meter,centi,inch; 
 int input; 
 cout <<"If you want to convert meters into feet type '1' or '2' if you want to convert feet into meters";
 cin >>input;
 if (input='1')
 //Input
 cout << "Enter the length in meters and then the remaining centimeters: "; 
 cin >> meter; 
 cin >> centi;
 //Conversions
 feet = meter/0.3048; 
 inch = feet * 12;
 centi = meter * 100;
 //Output data
 cout << meter << " meters are " << feet << " in feet.\n"; 
 cout << centi <<" in centimeters\n "
 cout << inch << "  in inches\n";
 cout << "try again '1' or '2'\n";
 cin >> input;
 if (input='2')
 {   
//Input
 cout << "Enter the length in feet and then the remaining inches: "; 
 cin >> feet; 
 cin >> inch;
 //Conversions
 meter = feet * 0.3048; 
 inch = feet * 12;
 centi =meter * 100;
 //Output data
 cout << feet << " in feet is " << meter << " in meters.\n"; 
 cout << inch << "in inches\n";
 cout << centi << "  in centimeters\n";
 cout << "try again '1' or '2'\n";
 cin >> input;
 }
  
cout << "End of program.";
    return 0;
}

