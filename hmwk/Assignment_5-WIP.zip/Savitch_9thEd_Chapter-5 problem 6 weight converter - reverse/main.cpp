/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on May 5, 2017, 2:47 PM
 * Purpose: Write a program that converts kilograms & grams into pounds & ounces.
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

int main()
{ 
 float pound,kgram,gram,ounce; 
 int input; 
 
 //Input
 cout << "Enter kilograms and then the remaining grams: "; 
 cin >> kgram; 
 cin >> gram;
 //Conversions
 gram = kgram * 1000;
 pound = kgram/2.2046; 
 ounce = pound * 16;
 //Output data
 cout << kgram << " kilograms are " << pound << " pounds.\n"; 
 cout << ounce << "  in ounces\n";
 cout << "try again 'y' or 'n'\n";
 cin >> input;
 if (input='y')
 {   
 return 0;
 }
  
cout << "End of program.";
    return 0;
}

