/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on May 5, 2017, 3:27 PM
 * Purpose: Write a program that combines the previous two weight convert programs.
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

int main()
{ 
 float pound,kgram,gram,ounce; 
 int input; 
 
 
 cout <<"If you want to convert pounds to kilograms type '1' or '2' to convert kilograms to pounds";
 cin >> input;
 if (input ='1')
 //Input
 cout << "Enter pounds and then the remaining ounces: "; 
 cin >> pound; 
 cin >> ounce;
 //Conversions
 
 ounce = pound * 16;
 kgram = pound * 2.2046 + ounce; 
 gram = kgram * 1000;
 //Output data
 cout << pound << " pounds are " << kgram << " kilograms.\n"; 
 cout << gram << "  in grams\n";
 cout << "try again '1' or '2'\n";
 cin >> input;
 if (input='2')
 {   
 //Input
 cout << "Enter kilograms and then the remaining grams: "; 
 cin >> kgram; 
 cin >> gram;
 //Conversions
 gram = kgram * 1000;
 pound = kgram/2.2046 + gram; 
 ounce = pound * 16;
 //Output data
 cout << kgram << " kilograms are " << pound << " pounds.\n"; 
 cout << ounce << "  in ounces\n";
 cout << "try again '1' or '2'\n";
 cin >> input;
 }
  
cout << "End of program.";
    return 0;
}

