/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on May 5, 2017, 2:51 PM
 * Purpose: Write a program to convert meters & centimeters into feet & inches.
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

int main()
{ 
 float feet, meter,centi,inch; 
 int input; 
 //Input
 cout << "Enter the length in meters and then the remaining centimeters: "; 
 cin >> meter; 
 cin >> centi;
 //Conversions
 feet = meter/0.3048; 
 inch = feet * 12;
 centi = meter * 100;
 //Output data
 cout << meter << " meters are " << feet << " in feet.\n"; 
 cout << inch << "  in inches\n";
 cout << "try again 'y' or 'n'\n";
 cin >> input;
 if (input='y')
 {   
 return 0;
 }
  
cout << "End of program.";
    return 0;
}

