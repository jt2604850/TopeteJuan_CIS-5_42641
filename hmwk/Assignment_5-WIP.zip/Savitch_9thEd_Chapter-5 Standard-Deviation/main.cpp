/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on May 5, 2017, 1:23 PM
 * Purpose: Write a program to find out the average and standard deviation of
 * four scores.
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

float calculateSD(float data[]);

int main()
{
    int i;
    float data[4];

    cout << "Enter in 4 elements: "<< endl;
    for(i = 0; i < 4; ++i)
        cin >> data[i];

    cout << "Standard Deviation = " << calculateSD(data);

    return 0;
}

float calculateSD(float data[])
{
    float sum = 0.0, average, standardDeviation = 0.0;

    int i;

    for(i = 0; i < 4; ++i)
    {
        sum += data[i];
    }

    average = sum/4;

    for(i = 0; i < 4; ++i)
        standardDeviation += pow(data[i] - average, 2);
    cout <<"The average: "<< average <<endl ;
    return sqrt(standardDeviation / 4);
}


