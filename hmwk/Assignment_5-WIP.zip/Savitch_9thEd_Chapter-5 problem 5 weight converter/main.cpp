/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on May 5, 2017, 2:27 PM
 * Purpose: Write a program that converts pounds & ounces into kilograms & grams.
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

int main()
{ 
 float pound,kgram,gram,ounce; 
 int input; 
 
 //Input
 cout << "Enter pounds and then the remaining ounces: "; 
 cin >> pound; 
 cin >> ounce;
 //Conversions
 ounce = pound * 16;
 kgram = pound * 2.2046; 
 gram = kgram * 1000;
 //Output data
 cout << pound << " pounds are " << kgram << " kilograms.\n"; 
 cout << gram << "  in grams\n";
 cout << "try again 'y' or 'n'\n";
 cin >> input;
 if (input='y')
 {   
 return 0;
 }
  
cout << "End of program.";
    return 0;
}

