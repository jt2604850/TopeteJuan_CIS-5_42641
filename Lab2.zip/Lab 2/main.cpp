/* 
  File:   main.cpp
  Author: Juan Topete
  Created on February 28, 2017, 8:15 PM
  Purpose: Create program to calculate profit made by taxes from gallons of gas.
 */  //39 cents for excise tax/gallon
     //8% sales tax
     //10 cents for cap and trade “fee”—tax on a tax/gallon
     //18.4 cents federal excise tax/gallon
     //Finally add the 7 cents/gallon the oil company makes for profit.
     


//System Libraries
#include <iostream>
using namespace std;





//Program sequence
int main(int argc, char** argv) 
{
 
    // Declared Values and Variables 
    float PERCENT=100.0f;
    float fedTax=0.184f, 
          caTax=0.390f,  
          cpTax=0.100f,  
          caSlsTx=0.08f, 
          oilPrft=0.07f;  
    float pumpPr,basePr; 
    float pctTax,pctPrft;
   
   // Input Sequence
    cout<<"What was the price you paid per gallon of gas?";
    cin>>pumpPr; // Price paid per gallon
    
    
    basePr=(pumpPr-fedTax-caTax-cpTax)/(1+caSlsTx);
    pctTax=(basePr*caSlsTx+fedTax+caTax+cpTax)/basePr*PERCENT;
    pctPrft=oilPrft/basePr*PERCENT;
    
    // Output sequence
    
    cout<<"Federal tax/gallon          = $"<<fedTax<<endl;
    cout<<"California Sales tax/gallon = $"<<caTax<<endl;
    cout<<"Cap and trade tax/gallon    = $"<<cpTax<<endl;
    cout<<"California sales tax/gallon = $"<<caSlsTx*basePr<<endl;
    cout<<"Base Price/gallon           = $"<<basePr<<endl;
    cout<<"Oil company profit/gallon   =  "<<pctPrft<<"%"<<endl;
    cout<<"Total percentage tax/Gallon/ =  "<<pctTax<<"%"<<endl;

    return 0;
}