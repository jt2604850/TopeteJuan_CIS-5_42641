/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on April 3, 2017, 10:05 AM
 * Purpose:  Menu to be utilized on Hmwk 4
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    char choice;
    
    //Show menu and loop
    do{
        //Display Menu
        cout<<endl<<endl<<"Type 0 to exit"<<endl;
        cout<<"Type 1 for Sum 1 to n Problem"<<endl;
        cout<<"Type 2 for Sum 0.1 error Problem"<<endl;
        cout<<"Type 3 for Problem 3"<<endl;
        cout<<"Type 4 for Problem 4"<<endl;
        cout<<"Type 5 for Problem 5"<<endl;
        cout<<"Type 6 for Problem 6"<<endl;
        cout<<"Type 7 for Problem 7"<<endl;
        cout<<"Type 8 for Problem 8"<<endl;
        cout<<"Type 9 for Problem 9"<<endl<<endl;
       
        //Input the choice
        cout<<"Problem ";
        cin>>choice;
        
        //Place solutions to problems in switch statement
        switch(choice){
            case '1':{
    
                //Declare variables
    float miles, gallons, liter, mpg;
    
    
   //Input
    cout << "Enter liters of gasoline"<<endl;
    cin >> liter;
    cout << "enter miles driven "<<endl;
    cin >> miles;
    
   //Conversion input to output
     gallons =.264179 * liter;
     mpg =miles/gallons;
   //Output transformed data
    cout << mpg <<" (miles per gallon) " ;
                break;
            }
            case '2':{
    //Declare and initialize variables           
    int liter1, liter2; 
    float miles1 ,mpg1, miles2,mpg2 ;
    
    
   //Input
    cout << "Enter liters of gasoline for car 1"<<endl;
    cin >> liter1;
    cout << "enter miles driven for car 1 "<<endl;
    cin >> miles1;
    cout << "Enter liters of gasoline for car 2"<<endl;
    cin >> liter2;
    cout << "enter miles driven for car 2 "<<endl;
    cin >> miles2;
   //Conversion map input to output
     mpg1 =miles1/liter1*.264179;
     mpg2 =miles2/liter2*.264179;
   //Output transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout << mpg1 <<" (miles per gallon for car 1) " <<endl;
    cout << mpg2 <<" (miles per gallon for car 2) " <<endl;
    if (mpg1 > mpg2)
        cout<<"The first car is more fuel efficient";
    else
        cout<<"The second car is more fuel efficient";
            }
            case '3':{
    
    //Declare variables
    float price,oldprice; //The current price and the year ago price
    double  percent; //Rate of inflation
    
    
   //Input
    cout << "Enter in the current price"<<endl;
    cin >> price;
    cout << "Enter in the old price from one year ago"<<endl;
    cin >> oldprice;
    
   //Conversion map input to output
    percent= price/oldprice;
   //Output transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout << "Inflation rate is "<<percent<<"%"<<endl;
                break;
            }
            case '4':{
//Declare variables
    float price,oldprice; //The current price and the year ago price
    double  percent,f1,f2; //Rate of inflation and estimated prices.
    
    
   //Input
    cout << "Enter in the current price"<<endl;
    cin >> price;
    cout << "Enter in the old price from one year ago"<<endl;
    cin >> oldprice;
    
   //Conversion map input to output
    percent= price/oldprice;
    f1= percent*oldprice-oldprice;
    f2= percent*price;
   //Output transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout << "Inflation rate is "<<percent<<"%"<<endl;
    cout << "The price the item gone up by $"<<f1<<endl;
    cout << "The estimated price for the item in one year $"<<f2<<endl;
                break;
            }
            case '5':{
                 //Declare variables
    float coin,twinkie;
    float dime,dollar,nickel,quarter;
    float total;
    
   //Input
    cout << "Deep fried twinkies $3.50"<<endl;
    cout << "Enter in a dollar, quarter, dime or nickel type one"<<endl;
    cin >> coin;
    
   //Conversion input to output
    //coin=dime,dollar,nickel,quarter;
    //dime=.1;
    //dollar=1.00;
    //nickel=.05;
    //quarter=.25;   

    
    twinkie=3.50;
       
     if (total <3.50)
         cout<<" "<<endl;
     else
     if (total = 3.50)
    
        cout<<"enjoy your deep fried twinkie";
     
     else
    if (total >3.50)
    
        cout<<"enjoy your deep fried twinkie take your change";
        
     


    
    while (coin=dime)
    {
        total=coin;
        cout<<"enter next coin or dollar";
        cin>>coin;
    }
    while (coin=1)
    {
        total=coin;
        cout<<"enter next coin or dollar";
        cin>>coin;
    }
    while (coin=.05)
    {
        total=coin;
        cout<<"enter next coin or dollar";
        cin>>coin;
    }
    while (coin=.25)
    {
        total=coin;
        cout<<"enter next coin or dollar";
        cin>>coin;
    }
                break;
            }
            case '6':{
 //Declare variables
    float price,mor; //The price of the house and annual mortgage
    float down, loan, tax, cost; //Initial loan, tax saving and down payment
    
    
   //Input
    cout << "Enter in the price of the house"<<endl;
    cin >> price;
    cout << "Enter in the down payment"<<endl;
    cin >> down;
    
   //Conversion map input to output
    tax=.35*down;
    loan = price-down;  
    mor = .03*loan+.06*loan;
    cost = mor-tax;
   //Output transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout << "The total cost of ownership for the first year is $"<<cost<<endl;
                break;
            }
             case '7':{
//Declare variables
    int height, weight,age; // information about user
    float hat, jacket,jackadj, waist,old,fat; //Hat, jacket, and waist sizes
    
    
   //Input
    cout << "Enter in your height in inches"<<endl;
    cin >> height;
    cout << "Your weight in pounds"<<endl;
    cin >> weight;
    cout << "What is your Age?"<<endl;
    cin >> age;
   //Conversion map input to output
    
    hat=weight/height*2.9;
    
    
    if (age>30) //Used to adjust jacket size for people over 30
        old=age-30*.125;
    else 
        old=0;
     if (age>28) //Used to adjust waist size for people over 28
        fat=age-28*.1;
    else 
        fat=0;   
    waist=weight/5.7+fat;
    jacket=height*weight;
    jackadj=jacket/288+old;
   //Output transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout << "According to our results your hat size is "<<hat<<"inches"<<endl;
    cout << "Your jacket size is "<<jackadj<<"inches"<<endl;
    cout << "Your waist measures "<<waist<<"inches"<<endl;
                break;
            }
            case '8':{
//Declare variables
    int height, weight,age; // information about user
    float hat, jacket,jackadj, waist,old,fat; //Hat, jacket, and waist sizes
    
    
   //Input
    cout << "Enter in your height in inches"<<endl;
    cin >> height;
    cout << "Your weight in pounds"<<endl;
    cin >> weight;
    cout << "What is your Age?"<<endl;
    cin >> age;
   //Conversion map input to output
    
    hat=weight/height*2.9;
    
    
    if (age>20) //Used to adjust jacket size for people over 30(after ten years)
        old=age-20*.125;
    else 
        old=0;
     if (age>18) //Used to adjust waist size for people over 28(after ten years)
        fat=age-18*.1;
    else 
        fat=0;   
    waist=weight/5.7+fat;
    jacket=height*weight;
    jackadj=jacket/288+old;
   //Output transformed data
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    cout << "Your hat size in 10 years will be "<<hat<<"inches"<<endl;
    cout << "Your jacket size in  10 years will be "<<jackadj<<"inches"<<endl;
    cout << "Your waist size in 10 years will be "<<waist<<"inches"<<endl;
                break;
            }
            case '9':{
  //Declare variables
    int beer;
    
   //Input
  
    cout << "Lyrics to ninety-nine bottles of beer on the wall"<<endl;
    
   //Conversion input to output
    beer=99;
    while (beer>0)
    {
        cout<<beer<<" bottles of beer on the wall,\n";
        cout<<beer<<" bottles of beer\n";
        cout<<"take one down,pass it around\n";
        cout<<beer<<" bottles of beer on the wall"<<endl;
        beer=beer-1;
    }
   //Output transformed data
  
            cout<< "That's it";
                break;
            }
            default:{
                cout<<"Exit the program"<<endl;
            }
        }
    }while(choice>='1'&&choice<='9');
    
    //Exit stage right!
    return 0;
}