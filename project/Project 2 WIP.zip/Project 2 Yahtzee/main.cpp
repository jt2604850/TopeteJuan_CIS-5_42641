/* 
 * File:   main.cpp
 * Author: Juan Topete
 * Created on May 25, 2017, 1:23 PM
 * Purpose: Project 2 - Yahtzee.
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <ctime>     //Time to set the seed
#include <cstdlib>   //Srand and rand function
#include <iomanip>   //Formatting output
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    
    //Declare variables
    int nThrws=1;//Number of throws
    int dec1,dec2,dec3,dec4,dec5,roll;//The dice you decide to keep out.
    int sum;//Sum of all dice.
    //Loop and throw the dice
    while(nThrws=1,2,3)
        int die1[6],die2[6],die3[6],die4[6],die5[6];
        sum= die1+die2+die3+die4+die5;
       if (roll =1) 
       {
           nThrws++;
       }
       if (nThrws<3){
            if (dec1 =1)
            {
                sum= sum-die1;
            }
            else cout <<"";
            if (dec2 =2)
            {
                sum= sum-die2;
            }
            else cout <<"";
            if (dec3 =3)
            {
                sum= sum-die3;
            }
            if (dec4 =4)
            {
                sum= sum-die4;
            }
            else cout <<"";
            if (dec5 =5)
            {
                sum= sum-die5;
            }
            else cout <<"";
        }
        void die1;
        die1[6]=rand()%6;
    
    //Output the transformed data
        
    cout<<"Start by rolling the dice."<<endl;
    cout<<"die thrown "<<" number of throws: "<<nThrws<<"Choose the dice to keep "<<endl;
    cin>>dec1,dec2,dec3,dec4,dec5,roll;
    cout<<sum; 
    //Exit stage right!
    return 0;
}

